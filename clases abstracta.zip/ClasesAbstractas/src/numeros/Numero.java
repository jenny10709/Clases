/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numeros;

/**
 *
 * @author fabrica1
 */
public abstract class Numero {
    protected float numero;

    protected Numero(float numero) {
        this.numero = numero;
    }
    
    public abstract void sumar(float n);
    public abstract void restar(float n);
    public abstract void multiplicarPor(float n);
    public abstract void dividirPor(float n);

    public float getNumero() {
        return numero;
    }

    public void setNumero(float numero) {
        this.numero = numero;
    }

    @Override
    public String toString() {
        return "Numero{" + "numero=" + numero + '}';
    }
    
    
    
    
}
